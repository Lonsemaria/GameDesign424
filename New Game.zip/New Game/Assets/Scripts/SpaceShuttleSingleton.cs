﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpaceShuttleSingleton{

	private static SpaceShuttleSingleton instance = null;
	private GameObject spaceShuttle = null;

	private SpaceShuttleSingleton(){}

	public static SpaceShuttleSingleton getInstance(){
		if (instance == null) {
			instance = new SpaceShuttleSingleton ();
		}
		return instance;
	}
		
	public void setSpaceShuttle(GameObject gameObject){
		spaceShuttle = gameObject;
	}
	public GameObject getSpaceShuttle (){
		if (spaceShuttle == null) {
			spaceShuttle = GameObject.Find ("spaceShuttle");
		}
		return spaceShuttle;
	}
}
