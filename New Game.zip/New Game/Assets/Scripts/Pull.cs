﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pull : MonoBehaviour {
	// Usse this for initialization
	private	GameObject spaceShuttle;
	private Rigidbody spaceShuttleRB;
	private Vector3 appliedForce = new Vector3(5f, 5f, 0f);
	private Vector3 selfCoordinates = new Vector3(0f, 0f, 0f);
	private Vector3 spaceShuttleCoordinates = new Vector3(0f, 0f, 0f);
	private float selfMass = 0f;
	private float spaceShuttleMass = 0f;
	private Vector3 distance = new Vector3(0f, 0f, 0f);
	private Transform spaceShuttleTransform = null;
	private Transform selfTransform = null;
	private float factor = 0f;

	void Start () {
		spaceShuttle = SpaceShuttleSingleton.getInstance ().getSpaceShuttle ();

		spaceShuttleRB = spaceShuttle.GetComponent<Rigidbody> ();
		spaceShuttleRB.AddForce(appliedForce);

		selfMass = GetComponent<Rigidbody>().mass;
		spaceShuttleMass = spaceShuttleRB.mass;

		selfTransform = gameObject.GetComponent<Transform> ();
		spaceShuttleTransform = spaceShuttle.GetComponent<Transform> ();

		selfCoordinates.x = selfTransform.position.x;
		selfCoordinates.y = selfTransform.position.y;
		spaceShuttleCoordinates.x = spaceShuttleTransform.position.x;
		spaceShuttleCoordinates.y = spaceShuttleTransform.position.y;

		factor = 6.67f * selfMass * spaceShuttleMass;
		distance = selfCoordinates - spaceShuttleCoordinates;
		appliedForce.x = factor / (Mathf.Pow(distance.x, 2));
		appliedForce.y = factor / (Mathf.Pow(distance.y, 2));
		spaceShuttleRB.AddForce (appliedForce);

	}

	// Update is called once per frame
	void Update () {
		selfCoordinates.x = selfTransform.position.x;
		selfCoordinates.y = selfTransform.position.y;
		spaceShuttleCoordinates.x = spaceShuttleTransform.position.x;
		spaceShuttleCoordinates.y = spaceShuttleTransform.position.y;
		distance = selfCoordinates - spaceShuttleCoordinates;
		appliedForce.x = factor / (Mathf.Pow(distance.x, 2));
		appliedForce.y = factor / (Mathf.Pow(distance.y, 2));

	}
}
