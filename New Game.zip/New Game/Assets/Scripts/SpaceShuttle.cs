﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpaceShuttle : MonoBehaviour {
	/* 
		Behavioral script of the spaceShuttle (player interactable object).
	*/
	void Start () {
		SpaceShuttleSingleton.getInstance().setSpaceShuttle(gameObject);
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.W)) {
			
		} else if (Input.GetKeyDown (KeyCode.A)) {
		
		} else if (Input.GetKeyDown (KeyCode.S)) {
		
		} else if (Input.GetKeyDown (KeyCode.D)) {
		
		}

	}
}
